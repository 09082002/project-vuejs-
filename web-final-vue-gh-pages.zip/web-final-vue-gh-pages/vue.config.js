module.exports = {
  publicPath: 'web-final-vue'
}
