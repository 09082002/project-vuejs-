# Virtual Jeopardy!

Populated using the jService REST API - http://jservice.io/, a database of every Jeopardy clue since its first episode.

Click on a dollar value to view a clue. Click on the clue to view the answer. Click on the answer to get back to the board.

Coming soon: score keeping, user authentication.
